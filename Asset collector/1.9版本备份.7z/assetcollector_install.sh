#!/bin/zsh

mkdir -p /root/asset_collector/tools
toolsPATH=/root/asset_collector/tools/
cd $toolsPATH

bar=$(yes "-" | head -n $(tput cols) | tr -d '\n')
echo "
   ___              __  _____     ____        __         
  / _ | ___ ______ / /_/ ___/__  / / /__ ____/ /____ ____
 / __ |(_-<(_-< -_) __/ /__/ _ \/ / / -_) __/ __/ -_) __/
/_/ |_/___/___|__/\__/\___/\___/_/_/\__/\__/\__/\__/_/   
                                by:soapffz

A tool use for Asset Collector.
"
echo -e "\n$bar\n\tBegin Asset Collector Tools Installtion\n$bar\n"

function InstallAssetsFinder() {
    echo -e "\n$bar\nInstalling Assets finder\n$bar\n"
    go get -u github.com/tomnomnom/assetfinder >>/dev/null 2>&1
    if [ $? -ne 0 ]; then InstallAssetsFinder; fi
}
function InstallFindomain() {
    echo -e "\n$bar\nInstalling Findomain\n$bar\n"
    cd $toolsPATH && proxychains curl -s -H "Authorization: token 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" https://api.github.com/repos/Findomain/Findomain/releases/latest | grep -E 'browser_download_url' | grep linux | cut -d '"' -f 4 | grep -v "i386" | proxychains wget -qi - >>/dev/null 2>&1
    if [ $? -ne 0 ]; then InstallFindomain; fi
    chmod +x findomain-linux
}
function InstallSubfinder() {
    echo -e "\n$bar\nInstalling Subfinder\n$bar\n"
    go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
    if [ $? -ne 0 ]; then InstallSubfinder; fi
}
function InstallSudomy() {
    echo -e "\n$bar\nInstalling Sudomy\n$bar\n"
    cd $toolsPATH && apt-get update -y && apt-get install jq nmap npm chromium parallel -y && npm i -g wappalyzer wscat && proxychains git clone https://github.com/screetsec/Sudomy && cd Sudomy/ && pip3 install -r requirements.txt >>/dev/null 2>&1
    if [ $? -ne 0 ]; then rm -rf $toolsPATH/Sudomy && InstallSudomy; fi
}
function InstallOneForAll() {
    echo -e "\n$bar\nInstalling OneForAll\n$bar\n"
    cd $toolsPATH && proxychains git clone https://github.com/shmilylty/OneForAll && cd OneForAll/ && pip3 install -r requirements.txt >>/dev/null 2>&1
    if [ $? -ne 0 ]; then rm -rf $toolsPATH/OneForAll && InstallOneForAll; fi
}
function InstallSublist3r() {
    echo -e "\n$bar\nInstalling Sublist3r\n$bar\n"
    cd $toolsPATH && proxychains git clone https://github.com/aboul3la/Sublist3r && cd Sublist3r/ && pip2 install -r requirements.txt >>/dev/null 2>&1
    if [ $? -ne 0 ]; then rm -rf $toolsPATH/Sublist3r && InstallSublist3r; fi
}
function InstallAmass() {
    echo -e "\n$bar\nInstalling Amass\n$bar\n"
    apt-get install amass -y >>/dev/null 2>&1
    if [ $? -ne 0 ]; then InstallAmass; fi
}
function Installgithub_subdomains() {
    echo -e "\n$bar\nInstalling github_subdomains\n$bar\n"
    cd $toolsPATH && proxychains wget https://raw.githubusercontent.com/gwen001/github-search/master/github-subdomains.py >>/dev/null 2>&1
    if [ $? -ne 0 ]; then rm -rf github-subdomains.py && Installgithub_subdomains; fi
    chmod +x github-subdomains.py && pip3 install colored >>/dev/null 2>&1
}
function Installshosubgo() {
    echo -e "\n$bar\nInstalling shosubgo\n$bar\n"
    local url=$(proxychains curl -s -H "Authorization: token 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" https://api.github.com/repositories/238991093/releases/latest | grep -E 'browser_download_url' | grep linux | cut -d '"' -f 4)
    local filename=$(echo $url | awk -F "/" '{print $NF}')
    cd $toolsPATH && proxychains wget $url && chmod +x $filename >>/dev/null 2>&1
    if [ $? -ne 0 ]; then Installshosubgo; fi
}
function Installmassdns_and_puredns() {
    echo -e "\n$bar\nInstalling massdns and puredns\n$bar\n"
    cd $toolsPATH && proxychains git clone https://github.com/blechschmidt/massdns && cd massdns/ && make && make install && cd $toolsPATH && rm -rf $toolsPATH/massdns/ && GO111MODULE=on go get github.com/d3mondev/puredns/v2 >>/dev/null 2>&1
    if [ $? -ne 0 ]; then Installmassdns_and_puredns; fi
}
function Installksubdomain() {
    echo -e "\n$bar\nInstalling ksubdomain\n$bar\n"
    apt-get install libpcap-dev -y
    local url=$(proxychains curl -s -H "Authorization: token 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" https://api.github.com/repos/knownsec/ksubdomain/releases/latest | grep -E 'browser_download_url' | grep linux | cut -d '"' -f 4)
    local filename=$(echo $url | awk -F "/" '{print $NF}')
    cd $toolsPATH && proxychains wget $url && unzip $filename && rm -rf $filename && chmod +x ksubdomain >>/dev/null 2>&1
    if [ $? -ne 0 ]; then Installksubdomain; fi
}
function Installhttpx() {
    echo -e "\n$bar\nInstalling httpx\n$bar\n"
    GO111MODULE=on go get -v github.com/projectdiscovery/httpx/cmd/httpx >>/dev/null 2>&1
    if [ $? -ne 0 ]; then Installhttpx; fi
}
function Installsubdomainizer() {
    echo -e "\n$bar\nInstalling subdomainizer\n$bar\n"
    cd $toolsPATH && proxychains git clone https://github.com/nsonaniya2010/SubDomainizer && cd SubDomainizer/ && pip3 install -r requirements.txt >>/dev/null 2>&1
    if [ $? -ne 0 ]; then rm -rf SubDomainizer && Installsubdomainizer; fi
}
function Installhttprobe() {
    echo -e "\n$bar\nInstalling httprobe\n$bar\n"
    go get -u github.com/tomnomnom/httprobe >>/dev/null 2>&1
    if [ $? -ne 0 ]; then Installhttprobe; fi
}
function Installgau() {
    echo -e "\n$bar\nInstalling gau\n$bar\n"
    GO111MODULE=on go get -u -v github.com/lc/gau >>/dev/null 2>&1
    if [ $? -ne 0 ]; then Installgau; fi
}
function Installcrawlergo() {
    echo -e "\n$bar\nInstalling crawlergo\n$bar\n"
    cd $toolsPATH && proxychains git clone https://github.com/Qianlitp/crawlergo && cd crawlergo/cmd/crawlergo && go build crawlergo_cmd.go
    if [ $? -ne 0 ]; then cd $toolsPATH && rm -rf crawlergo/ && Installcrawlergo; fi
    mv crawlergo_cmd $toolsPATH/crawlergo_cmd && cd $toolsPATH && rm -rf crawlergo/ && mv crawlergo_cmd crawlergo
}
function Installgospider() {
    echo -e "\n$bar\nInstalling gospider\n$bar\n"
    go get -u github.com/jaeles-project/gospider >>/dev/null 2>&1
    if [ $? -ne 0 ]; then Installgospider; fi
}
function Installhakrawler() {
    echo -e "\n$bar\nInstalling hakrawler\n$bar\n"
    go get github.com/hakluke/hakrawler >>/dev/null 2>&1
    if [ $? -ne 0 ]; then Installhakrawler; fi
}
function Installparamspider() {
    echo -e "\n$bar\nInstalling paramspider\n$bar\n"
    cd $toolsPATH && proxychains git clone https://github.com/devanshbatham/ParamSpider && cd ParamSpider && pip3 install -r requirements.txt >>/dev/null 2>&1
    if [ $? -ne 0 ]; then rm -rf $toolsPATH/ParamSpider/ && Installparamspider; fi
}
function Installgf() {
    print -P "\n$bar\n%F{red}Installing gf maybe error%f\n$bar"
    if [ -d "/root/.gf" ]; then rm -rf /root/.gf; fi
    go get -u github.com/tomnomnom/gf && mkdir ~/.gf && cd ~/.gf && proxychains git clone https://github.com/tomnomnom/gf/ && cp gf/examples/*.json ./ && proxychains git clone https://github.com/1ndianl33t/Gf-Patterns && cp Gf-Patterns/*.json ./ && rm -rf urls.json >>/dev/null 2>&1
    if [ $? -ne 0 ]; then rm -rf ~/.gf && Installgf; fi
    echo 'source ~/.gf/gf/gf-completion.zsh' >>~/.zshrc && source ~/.zshrc
    print -P "\n$bar\n%F{red}If Installing gf error execute command 'source ~/.zshrc'%f\n$bar"
}
function Installffuf() {
    echo -e "\n$bar\nInstalling ffuf\n$bar\n"
    go get -u github.com/ffuf/ffuf >>/dev/null 2>&1
    if [ $? -ne 0 ]; then Installffuf; fi
}
function Installqsreplace() {
    echo -e "\n$bar\nInstalling qsreplace\n$bar\n"
    go get -u github.com/tomnomnom/qsreplace >>/dev/null 2>&1
    if [ $? -ne 0 ]; then Installqsreplace; fi
}
function Installuddup() {
    echo -e "\n$bar\nInstalling uddup\n$bar\n"
    pip3 install uddup >>/dev/null 2>&1
    if [ $? -ne 0 ]; then Installuddup; fi
}
function Installurldedupe() {
    echo -e "\n$bar\nInstalling urldedupe\n$bar\n"
    cd $toolsPATH && proxychains git clone https://github.com/ameenmaali/urldedupe && cd urldedupe && cmake CMakeLists.txt && make >>/dev/null 2>&1
    if [ $? -ne 0 ]; then rm -rf $toolsPATH/urldedupe/ && Installurldedupe; fi
    cd $toolsPATH && mv urldedupe/ urldedupe_folder/ && mv urldedupe_folder/urldedupe $toolsPATH && rm -rf urldedupe_folder/
}
function InstallAstra() {
    echo -e "\n$bar\nInstalling Astra\n$bar\n"
    cd $toolsPATH && proxychains git clone https://github.com/Sachin-v3rma/Astra && cd Astra/ && pip3 install -r requirements.txt >>/dev/null 2>&1
    if [ $? -ne 0 ]; then rm -rf $toolsPATH/Astra/ && InstallAstra; fi
    cd $toolsPATH/Astra/ && pip3 install -r requirements.txt && mv $toolsPATH/Astra/Astra.py $toolsPATH && rm -rf $toolsPATH/Astra/
}
function Installunfurl() {
    echo -e "\n$bar\nInstalling unfurl\n$bar\n"
    cd $toolsPATH && go get -u github.com/tomnomnom/unfurl
    if [ $? -ne 0 ]; then Installunfurl; fi
}
function Installnuclei() {
    echo -e "\n$bar\nInstalling nuclei\n$bar\n"
    # nuclei安装不能添加输出重定向符号
    cd $toolsPATH && GO111MODULE=on go get -v github.com/projectdiscovery/nuclei/v2/cmd/nuclei
    if [ $? -ne 0 ]; then Installnuclei; fi
    nuclei -ut
}
function Installanew() {
    echo -e "\n$bar\nInstalling anew\n$bar\n"
    go get -u github.com/tomnomnom/anew
    if [ $? -ne 0 ]; then Installanew; fi

}
function convert_time_format() {
    # 秒数格式化输出函数，输入为程序运行秒数，输出为格式化的时间字符串
    SEC=$1
    ((SEC < 60)) && echo -e "$SEC seconds\c"
    ((SEC >= 60 && SEC < 3600)) && echo -e "$((SEC / 60)) min $((SEC % 60)) seconds\c"
    ((SEC > 3600)) && echo -e "$((SEC / 3600)) hr $(((SEC % 3600) / 60)) min $(((SEC % 3600) % 60))  seconds\c"
}
main() {
    local startTime=$(date +%Y%m%d-%H:%M)
    local startTime_s=$(date +%s)
    InstallAssetsFinder
    InstallFindomain
    InstallSubfinder
    InstallSudomy
    InstallOneForAll
    InstallSublist3r
    InstallAmass
    Installgithub_subdomains
    Installshosubgo
    Installmassdns_and_puredns
    Installksubdomain
    Installhttpx
    Installsubdomainizer
    Installhttprobe
    Installgau
    Installcrawlergo
    Installgospider
    Installhakrawler
    Installparamspider
    Installgf
    Installffuf
    Installqsreplace
    Installuddup
    Installurldedupe
    InstallAstra
    Installunfurl
    Installnuclei
    Installanew
    cd $toolsPATH && chmod +x *.py
    local endTime=$(date +%Y%m%d-%H:%M)
    local endTime_s=$(date +%s)
    local sumTime=$(($endTime_s - $startTime_s))
    echo -e "\n$barDone! From $startTime To $endTime\nElapsed time:\c"
    convert_time_format $sumTime
}
main
