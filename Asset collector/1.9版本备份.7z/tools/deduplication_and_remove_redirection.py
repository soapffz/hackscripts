#!/usr/bin/env python
# 去重去除重定向http换https限制为enumerate_origin.txt中域名的url(根域名在文件中)
# 传入参数依次为，原url链接路径，新的url链接路径，域名枚举结果文件
import tldextract
import sys

request_tools_flag = False
origin_path = sys.argv[1]
new_path = sys.argv[2]
subdomain_list = [open(sys.argv[3], "r").read().splitlines()][0]
request_tools_flag = True if ("httpx" or "httprobe" in origin_path) else False
url_l = []
with open(origin_path, "r") as f1:
    with open(new_path, "a+") as f2:
        for line in f1.read().splitlines():
            url = line.split("[")[1].replace("]", "").strip() if "[" in line and request_tools_flag else line.strip()
            if tldextract.extract(url).registered_domain in subdomain_list:
                if url not in url_l:
                    if url.split("://")[0] == "http" and url.replace("http://", "https://") in url_l:
                        continue
                    elif url.split("://")[0] == "https" and url.replace("https://", "http://") in url_l:
                        url_l.remove(url.replace("https://", "http://"))
                        url_l.append(url)
                    else:
                        url_l.append(url)
        [f2.write(url+"\n") for url in url_l]
