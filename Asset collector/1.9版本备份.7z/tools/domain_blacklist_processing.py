#!/usr/bin/env python
# 域名黑名单处理脚本
# 支持单个域名及通配符域名的黑名单处理
# 传入参数第一个为原始枚举后合并原始输入域名数组及子域名数组后的文件，第二个为黑名单数组，第三个参数为处理之后的文件位置
# 使用argpasr解析能直接把以空格为分割的shell数组直接转换为python数组
import argparse
import tldextract

parser = argparse.ArgumentParser()
parser.add_argument("domain", nargs="+")
parser.add_argument("black", nargs="+")
parser.add_argument("result", nargs="+")
args = parser.parse_args()
domain_enumerate_list = [domain.strip() for domain in open(
    "{}".format(args.domain[0]), "r+").readlines()]
black_domain_list = args.black
resultPATH = args.result[0]
# 把black_list分为两部分，分别处理单个域名和通配符域名，单个域名直接列表去除列表，通配符需要对单个域名列表处理后的列表取根域名
black_single_domain_list = []
black_wildcard_domain_list = []
for black_domain in black_domain_list:
    if "*" in black_domain:
        black_wildcard_domain_list.append(black_domain.strip("*."))
    else:
        black_single_domain_list.append(black_domain)
# 如果黑名单列表既有单个域名列表，又有通配符列表，则先处理单域名列表，得到的结果再处理通配符列表
if black_single_domain_list and black_wildcard_domain_list:
    domain_list = [
        domain for domain in domain_enumerate_list if domain not in black_single_domain_list]
    for domain in domain_list:
        if tldextract.extract(domain).registered_domain in black_wildcard_domain_list:
            domain_list.remove(domain)
elif black_single_domain_list:
    domain_list = [
        domain for domain in domain_enumerate_list if domain not in black_single_domain_list]
else:
    domain_list = []
    for domain in domain_enumerate_list:
        if tldextract.extract(domain).registered_domain not in black_wildcard_domain_list:
            domain_list.append(domain)
with open("{}".format(resultPATH), "a+") as f:
    for domain in domain_list:
        f.write(domain+"\n")
