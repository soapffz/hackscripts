#!/usr/bin/env python
# 域名列表获取根域名脚本，用于在根域名拓展完之后获取根域名去进行枚举
# 传入参数为域名列表的shell数组，输出为根域名列表
import argparse
import tldextract

parser = argparse.ArgumentParser()
parser.add_argument("domain", nargs="+")
args = parser.parse_args()
domain_list = args.domain
root_domain_list = []
for domain in domain_list:
    root_domain = tldextract.extract(domain).registered_domain
    if root_domain not in root_domain_list:
        root_domain_list.append(root_domain)
print(" ".join(root_domain_list).rstrip())
