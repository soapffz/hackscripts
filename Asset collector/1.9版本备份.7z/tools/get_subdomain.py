#!/usr/bin/env python
# 域名列表获取根域名脚本，用于在根域名拓展完之后获取子域名留存
# 传入参数为域名列表的shell数组，输出为子域名列表
import argparse
import tldextract

parser = argparse.ArgumentParser()
parser.add_argument("domain", nargs="+")
args = parser.parse_args()
domain_list = args.domain
subdomain_list = []
for domain in domain_list:
    if domain != tldextract.extract(domain).registered_domain:
        subdomain_list.append(domain)
print(" ".join(subdomain_list).rstrip())
