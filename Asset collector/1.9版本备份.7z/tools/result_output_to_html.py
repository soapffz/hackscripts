#!/usr/bin/env python
# 结果输出到html的python脚本，固定html模板，使用javascript和python配合进行填充
# 灵感来自于https://github.com/qianxiao996/Super-PortScan/blob/master/Super-PortScan.py

